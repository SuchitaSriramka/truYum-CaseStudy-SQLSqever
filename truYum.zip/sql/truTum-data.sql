-- 1. View Menu Item List Admin (TYUC001)

-- a. Frame insert scripts to add data into menu_item table

insert into menu_item (item_name,price,active_status,date_launch,category,free_delivery) 
values ('Sandwich','99.00',1,'2017/03/15','Main Course',1),
('Burger','129.00',1,'2017/12/23','Main Course',0),
('Pizza','149.00',1,'2017/08/21','Main Course',0),
('French Fries','57.00',0,'2017/07/02','Starter',1),
('Chocolate Brownie','32.00',1,'2022/11/02','Dessert',1)

select * from menu_item;

-- b. Frame SQL query to get all menu items
select item_name as Name,concat('Rs. ',price) as Price,active_status as Active,date_launch as 'Date of Launch',
category as Category,free_delivery as 'Free Delivery' from menu_item;

-- 2. View Menu Item List Customer (TYUC002)

-- a. Frame SQL query to get all menu items which is before launch date and is active.
select item_name as Name,free_delivery as 'Free Delivery',concat('Rs. ',price) as Price,category as Category
 from menu_item 
where date_launch< cast(getdate() as date) and active_status = 1;

SELECT CAST( GETDATE() AS Date ) ;

-- 3. Edit Menu Item (TYUC003)

-- a. Frame SQL query to get a menu items based on Menu Item Id
select item_name as Name,price as 'Price(Rs.)',active_status as Active,date_launch as 'Date of Launch',
category as Category,free_delivery as 'Free Delivery' from menu_item
where menu_item_id = 1;

-- b. Frame update SQL menu_items table to update all the columns values based on Menu Item Id
update menu_item
set item_name = 'Sandwich', price = '97.00', active_status = 1, date_launch = '2022/04/27', category = 'Main Course', free_delivery = 1
where menu_item_id = 1;

-- 4. Add to Cart (TYUC004)

-- a. Frame insert scripts for adding data into user and cart tables.In user table create two users.
-- One user will not have any entries in cart, while the other will have at least 3 items in the cart.
insert into user_details (user_name) values ('Nicolas'),('Amber');
insert into cart(user_id,menu_item_id) values (2,1),(2,2),(2,3);
select * from user_details;
select * from Cart

-- 5. View Cart (TYUC005)

-- a. Frame SQL query to get all menu items in a particular user�s cart

select m.item_name as Name, m.free_delivery as 'Free Delivery',concat('Rs. ',price) as Price from menu_item m 
join cart c on m.menu_item_id = c.menu_item_id
join user_details u on c.user_id = u.user_id;

-- b. Frame SQL query to get the total price of all menu items in a particular user�s cart
select concat('Rs. ',cast(sum(m.price) as char)) as Total from menu_item m
join cart c on m.menu_item_id = c.menu_item_id
join user_details u on c.user_id = u.user_id;

-- 6. Remove Item from Cart (TYUC006)

-- a. Frame SQL query to remove a menu items from Cart based on User Id and Menu Item Id
delete from cart where user_id = 2 and menu_item_id = 3;
