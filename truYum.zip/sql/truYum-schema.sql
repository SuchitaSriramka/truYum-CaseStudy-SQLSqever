create database truYum
use truYum

create table menu_item(
	menu_item_id int identity primary key,
    item_name varchar(50),
    price decimal(7,2),
    active_status bit,
    date_launch varchar(10),
    category varchar(20),
    free_delivery bit
)


select * from menu_item

create table user_details(
	user_id int primary key identity,
    user_name varchar(50)
)

select * from user_details

create table Cart(
	cart_id int primary key identity,
    user_id int,
    menu_item_id int,
    constraint fk_user_id foreign key (user_id) references user_details(user_id),
    constraint fk_menu_item_id foreign key (menu_item_id) references menu_item(menu_item_id)
)

select * from Cart

select * from INFORMATION_SCHEMA.TABLES